# Production Architecture

## Technology

Use React + TypeScript + Vite for the production application.

The current `prototype/` is intentionally dependency free and serves as a behavioural reference only.

## Proposed source layout

```text
src/
  music/
    pitch.ts
    spelling.ts
    intervals.ts
    fretboard.ts
    chords.ts
    caged.ts
    scales.ts
    progressions.ts
    types.ts

  learning/
    types.ts
    generators/
      findNote.ts
      findInterval.ts
      completeTriad.ts
      transfer.ts
      harmonyTarget.ts
    evaluator.ts
    feedback.ts
    difficulty.ts

  components/
    Fretboard/
      Fretboard.tsx
      FretPosition.tsx
      FretMarker.tsx
      geometry.ts
    ModeTabs.tsx
    GuidanceControl.tsx
    ExerciseCard.tsx
    ProgressionBar.tsx

  modes/
    Explore/
    Navigate/
    Harmony/

  storage/
    indexedDb.ts
    attemptRepository.ts
    exportHistory.ts

  app/
    App.tsx
    routes-or-mode-state.ts
```

## Domain boundaries

### Music domain

Pure deterministic functions only. It must not import React, browser storage or UI code.

Examples:

```ts
getNoteAt(stringIndex, fret)
getInterval(root, note)
spellMajorScale(root)
getMajorTriad(root)
getCagedVoicing(root, shape)
getMajorProgression(root, [1,4,5,1])
```

### Learning domain

Turns musical facts into tasks, valid-answer sets, difficulty rules and feedback.

Exercise objects should be serialisable where practical.

Example concept:

```ts
{
  type: 'find_interval',
  root: 'A',
  interval: 'M3',
  anchor: { string: 6, fret: 5 },
  constraints: { fretRadius: 5, stringRadius: 2 }
}
```

### UI

Renders state and sends user actions to evaluators. UI components must not contain duplicated theory calculations.

### Storage

Append-only attempt events in v0.2. IndexedDB is the primary store. Export to JSON is required.

## Pitch representation

Internally distinguish pitch class from display spelling.

Do not use display strings such as `Bb` as the only identity of a pitch. Enharmonic spellings can represent the same pitch class while having different theoretical roles.

Recommended concepts:

- pitch class: integer 0–11
- spelled note: letter + accidental
- interval: typed semantic value such as M3/P5 plus semitone count

## Fretboard representation

Standard tuning only in v0.2:

- string 6: E
- string 5: A
- string 4: D
- string 3: G
- string 2: B
- string 1: E

Internally, choose one stable string-index convention and document it. Do not mix UI string numbers with zero-based array indexes.

## Telemetry event design

Attempt events should be versioned and append-only. Avoid deriving “mastery” at write time. Store raw evidence and compute mastery later.

## No backend yet

Do not add authentication, cloud sync or a database service in v0.2. The cost and complexity are not justified until the learning loop has been validated through real use.
